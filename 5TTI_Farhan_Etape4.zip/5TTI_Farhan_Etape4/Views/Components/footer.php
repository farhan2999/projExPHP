<footer>
    <div class="flexible space-between align-item-center">
        <div>
            <img class="imageIcon" src="../Assets/Images/icon1.jpg" alt="image twitter">
            <img class="imageIcon" src="../Assets/Images/icon2.jpg" alt="image facebook">
            <img class="imageIcon" src="../Assets/Images/icon3.jpg" alt="image google">
        </div>
    </div>
</footer>